#!/bin/bash
echo "Ejecutando exportación desde MongoDB a CSV..."
source venv/bin/activate
python mongo_to_csv.py