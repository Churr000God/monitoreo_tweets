# 🐦 Sistema Inteligente de Monitoreo de Tweets y Encuestas

Este sistema automatiza la recopilación y análisis de datos desde la red social X (Twitter) y encuestas locales, procesando sentimiento, ubicación y tema. Los datos se almacenan en MongoDB Atlas y pueden ser visualizados en Power BI.

---

## 📁 Estructura del Proyecto

```
MONITOREO_TWEETS/
├── data/
│   ├── datos_mongo.csv
│   ├── DatosEncuesta.xlsx
│   ├── tweets.csv
│   └── tweets_with_sentiment.csv
├── venv/ (entorno virtual)
├── .env
├── .env.example
├── .gitignore
├── README.md
├── requirements.txt
├── ejecutar_exportacion.bat
├── ejecutar_exportacion.sh
├── fetch_tweets.py
├── main.py
├── Datos_Encuesta.py
├── mongo_to_csv.py
└── upload_to_mongo.py
```

---

## ⚙️ Requisitos

- Python 3.11
- MongoDB Atlas (URI)
- Cuenta de desarrollador en X (Twitter API v2)
- Power BI Desktop

---

## 🚀 Ejecución automática

### En Linux:
```bash
chmod +x ejecutar_exportacion.sh
./ejecutar_exportacion.sh
```

### En Windows:
Doble clic en `ejecutar_exportacion.bat`

Esto ejecutará los siguientes scripts:

1. `main.py` – descarga, analiza y clasifica tweets
2. `upload_to_mongo.py` – guarda los datos en MongoDB
3. `mongo_to_csv.py` – exporta la colección de MongoDB a CSV
4. `Datos_Encuesta.py` – carga los datos de encuesta desde Excel

---

## 🔐 Configuración del entorno (.env)

Crea un archivo `.env` basado en el ejemplo:

```env
BEARER_TOKEN=tu_token_de_twitter
MONGODB_URI=tu_uri_de_mongo
```

---

## 📊 Visualización en Power BI

1. Abre Power BI Desktop
2. Conecta `data/datos_mongo.csv` y `data/DatosEncuesta.xlsx`
3. Crea un dashboard con al menos 6 visualizaciones:
   - 2 o 3 con datos de tweets
   - 3 o más con datos de encuesta

---

## 📌 Notas Adicionales

- Puedes verificar los datos en MongoDB Atlas con la consola o usando `verificar_contenido.py`
- Si usas la API gratuita de Twitter, se recomienda limitar las consultas y usar pausas para evitar bloqueos