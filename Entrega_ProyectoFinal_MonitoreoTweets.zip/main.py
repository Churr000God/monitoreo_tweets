import pandas as pd
from textblob import TextBlob
from fetch_tweets import fetch_tweets_v2
import os

# Listas de alcaldías y servicios para clasificar
alcaldias = ["Iztapalapa", "Benito Juárez", "Coyoacán", "Tlalpan", "Miguel Hidalgo", "Venustiano Carranza", "Álvaro Obregón"]
servicios = ["policía", "seguridad", "tránsito", "vialidad", "guardia", "emergencia", "patrulla"]

# Función para clasificar sentimiento
def analizar_sentimiento(texto):
    sentimiento = TextBlob(texto)
    polaridad = sentimiento.sentiment.polarity
    if polaridad > 0.1:
        return "Positivo"
    elif polaridad < -0.1:
        return "Negativo"
    else:
        return "Neutral"

# Función principal
def main():
    print("📥 Obteniendo tweets...")
    queries = ['@GN_MEXICO_', '@SSPCMexico', '@SSC_CDMX', '@Claudiashein', '@GobCDMX', '@ach_CDMX', '@INEGI_INFORMA']
    tweets = fetch_tweets_v2(queries)

    if not tweets:
        print("❌ No se obtuvieron tweets.")
        return

    print("🧠 Enriqueciendo tweets...")
    for tweet in tweets:
        texto = tweet['Text'].lower()
        tweet['Sentimiento'] = analizar_sentimiento(tweet['Text'])

        tweet['Alcaldía'] = next((a for a in alcaldias if a.lower() in texto), None)
        tweet['Servicio'] = next((s for s in servicios if s.lower() in texto), None)

    print("💾 Guardando en 'data/tweets_with_sentiment.csv'...")
    os.makedirs("data", exist_ok=True)
    df = pd.DataFrame(tweets)
    df.to_csv("data/tweets_with_sentiment.csv", index=False)

    print("✅ Proceso completado: Tweets con sentimiento y clasificación de alcaldía/servicio guardados.")

if __name__ == "__main__":
    main()